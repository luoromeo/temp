System.register([],(function(e,t){"use strict";return{execute:function(){e("t","/assets/empty_order-d0df2be9.png")}}}));
