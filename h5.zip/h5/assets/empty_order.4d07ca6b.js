const e="/assets/empty_order-d0df2be9.png";export{e as t};
