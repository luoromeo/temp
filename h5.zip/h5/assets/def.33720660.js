const s="/static/images/icon/def.png";export{s as _};
