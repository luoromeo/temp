System.register([],(function(c,e){"use strict";return{execute:function(){c("_","/static/images/icon/search-col.png"),c("a","/static/images/icon/search-col2.png")}}}));
