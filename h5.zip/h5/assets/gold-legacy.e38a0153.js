System.register([],(function(e,t){"use strict";return{execute:function(){e("_","/assets/gold-4dfc70aa.png")}}}));
