const o="/static/images/icon/more.png";export{o as _};
