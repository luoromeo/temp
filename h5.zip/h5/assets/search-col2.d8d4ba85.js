const a="/static/images/icon/search-col.png",c="/static/images/icon/search-col2.png";export{a as _,c as a};
