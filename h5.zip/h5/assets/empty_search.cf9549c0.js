const s="/assets/empty_search-6fda42e5.png";export{s as t};
