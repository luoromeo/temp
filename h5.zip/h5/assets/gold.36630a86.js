const s="/assets/gold-4dfc70aa.png";export{s as _};
