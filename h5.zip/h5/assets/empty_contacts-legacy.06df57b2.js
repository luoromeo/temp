System.register([],(function(t,e){"use strict";return{execute:function(){t("e","/assets/empty_contacts-69f72654.png")}}}));
