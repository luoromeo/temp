const s="/static/images/icon/close.png";export{s as _};
