const s="/assets/status-bg-6de9f13e.png";export{s as _};
