const s="/static/images/icon/clear-his.png";export{s as _};
