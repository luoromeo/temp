const s="/assets/head04-6d2f6067.png";export{s as h};
