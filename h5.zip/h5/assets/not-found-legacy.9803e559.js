System.register([],(function(e,t){"use strict";return{execute:function(){e("e","/assets/not-found-67f6722e.png")}}}));
