System.register([],(function(e,t){"use strict";return{execute:function(){e("_","/static/images/icon/search.png")}}}));
