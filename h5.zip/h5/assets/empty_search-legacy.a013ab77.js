System.register([],(function(e,t){"use strict";return{execute:function(){e("t","/assets/empty_search-6fda42e5.png")}}}));
