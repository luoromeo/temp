System.register([],(function(e,t){"use strict";return{execute:function(){e("_","/assets/status-bg-6de9f13e.png")}}}));
