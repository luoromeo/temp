const s="/assets/not-found-67f6722e.png";export{s as e};
