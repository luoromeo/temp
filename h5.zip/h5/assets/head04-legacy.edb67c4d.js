System.register([],(function(e,t){"use strict";return{execute:function(){e("h","/assets/head04-6d2f6067.png")}}}));
