const s="/static/images/icon/search.png";export{s as _};
