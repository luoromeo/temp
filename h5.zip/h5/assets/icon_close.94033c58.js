const c="/static/images/icon/icon_close.png";export{c as _};
