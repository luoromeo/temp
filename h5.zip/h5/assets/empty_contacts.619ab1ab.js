const s="/assets/empty_contacts-69f72654.png";export{s as e};
